# Author: CaptainIcicle
# Paypal: https://www.paypal.me/monroe607
# Version: 1.0

# What is BridgeVPN Client?
BridgeVPN Client is a client that will auto connect and give you the option to either bridge your connection on tor and or just use it as a normal vpn.

# Why choose VPN Client?
VPN Client takes the work out of being anonymous and anonymizing what you do for you in an extremely secure way.

# Troubleshooting:
If your client/vpn doesn't run, it is most likely going to be your vpn file path. This can be configurred in the the script.
Linux: 
Use nano editor or what ever editor your prefer and follow along: [I'm using nano editor for this, but you can use what ever editor youu would like]
nano BridgeVPN.sh - This opens the file config
Now you should see a note the says: #If the directory path is wrong change the path below
[/home/oem/] - Change this directory depending on your linux distro!

