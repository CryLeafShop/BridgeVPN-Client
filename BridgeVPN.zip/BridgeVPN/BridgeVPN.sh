#!/bin/bash

clear
echo "Welcome to Bridge vpn bridge client!"
echo " "
sleep 1s
echo "==================================================="
echo " I am not responsible for the misuse of this script"
echo "==================================================="
sleep 4s
PS3='Select an option: '
options=("VPN only" "Bridge" "Donate" "Quit")
select opt in "${options[@]}"
do
    case $opt in
        "VPN only")
            echo "Starting VPN..."
            echo " "
            echo "=============================================="
            echo "=              Username: vpnbook             ="
            echo "=              Password: 8a36tna             ="
            echo "=============================================="
	    #If the directory path is wrong change the path below
            openvpn /home/oem/Desktop/BridgeVPN/vpn/vpnbook-fr1-udp25000.ovpn
            ;;
        "Bridge")
            echo "Starting bridge..."
	    echo "if you are using Tor browser you will have to disconnect from the bridge"
	    echo " "
	    echo "=============================================="
	    echo "=              Username: vpnbook             ="
	    echo "=              Password: 8a36tna             ="
	    echo "=============================================="
            #If the directory path is wrong change the path below
            openvpn /home/oem/Desktop/BridgeVPN/vpn/vpnbook-fr1-udp25000.ovpn
            service start tor
            ;;
        "Donate")
            echo "https://www.paypal.me/monroe607"
            ;;
        "Quit")
            break
            ;;
        *) echo "invalid option $REPLY";;
    esac
done
