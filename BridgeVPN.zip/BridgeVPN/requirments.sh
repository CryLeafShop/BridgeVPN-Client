#!/bin/bash

clear
echo "Installing necessary files..."
sudo apt-get install tor -y
sleep 1s
echo "Installed!"
sleep 3s

